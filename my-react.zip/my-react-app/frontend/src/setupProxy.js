const { createProxyMiddleware } = require("http-proxy-middleware");

module.exports = function (app) {
  app.use(
    "/api",
    createProxyMiddleware({
      // ใช้ค่าจาก Environment Variable ถ้ามี หรือใช้ localhost เป็นค่าเริ่มต้น
      target: process.env.BACKEND_URL || "http://localhost:8080",
      changeOrigin: true,
    }),
  );
};
